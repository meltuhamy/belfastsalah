import type CalculationMethod from './CalculationMethod.js';
import { Madhab } from './Madhab.js';
import HighLatitudeRule from './HighLatitudeRule.js';
import { PolarCircleResolution } from './PolarCircleResolution.js';
import { Rounding } from './Rounding.js';
import { Shafaq } from './Shafaq.js';
import { SolarModel } from './SolarModel.js';
import { SolarEphemeris } from './SolarEphemeris.js';
import { ValueOf } from './TypeUtils.js';
export type Interval = number | ((date: Date) => number);
export type Adjustments = {
    fajr: number;
    sunrise: number;
    dhuhr: number;
    asr: number;
    maghrib: number;
    isha: number;
};
export type ElevationFromHorizon = number | {
    sunrise: number;
    sunset: number;
};
export default class CalculationParameters {
    method: null | keyof typeof CalculationMethod;
    fajrAngle: number;
    ishaAngle: number;
    ishaInterval: Interval;
    maghribAngle: number;
    madhab: ValueOf<typeof Madhab>;
    highLatitudeRule: ValueOf<typeof HighLatitudeRule>;
    adjustments: {
        fajr: number;
        sunrise: number;
        dhuhr: number;
        asr: number;
        maghrib: number;
        isha: number;
    };
    methodAdjustments: {
        fajr: number;
        sunrise: number;
        dhuhr: number;
        asr: number;
        maghrib: number;
        isha: number;
    };
    methodDailyAdjustments: ((date: Date) => Partial<Adjustments>) | null;
    polarCircleResolution: ValueOf<typeof PolarCircleResolution>;
    rounding: ValueOf<typeof Rounding>;
    shafaq: ValueOf<typeof Shafaq>;
    elevationFromHorizon: ElevationFromHorizon;
    solarModel: ValueOf<typeof SolarModel>;
    solarPositionHour: number;
    solarEphemeris: ValueOf<typeof SolarEphemeris>;
    fajrInterval: Interval;
    constructor(method: null | keyof typeof CalculationMethod, fajrAngle?: number, ishaAngle?: number, ishaInterval?: Interval, maghribAngle?: number);
    intervals(date: Date): {
        fajr: number;
        isha: number;
    };
    nightPortions(): {
        fajr: number;
        isha: number;
    };
    horizonElevations(): {
        sunrise: number;
        sunset: number;
    };
}
