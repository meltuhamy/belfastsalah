export declare function diyanetDailyAdjustments(date: Date): {
    [prayer: string]: number;
};
export declare const DIYANET_ISTANBUL: {
    readonly latitude: 41.014;
    readonly longitude: 28.972;
};
