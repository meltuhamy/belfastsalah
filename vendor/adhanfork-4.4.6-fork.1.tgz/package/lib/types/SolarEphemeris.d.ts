export declare const SolarEphemeris: {
    readonly Meeus: "meeus";
    readonly Usno: "usno";
};
/**
 * The sun's declination (degrees) and the equation of time (minutes) at a
 * julian day, from the U.S. Naval Observatory's low-precision formulas.
 */
export declare function usnoSolarPosition(julianDay: number): {
    declination: number;
    equationOfTime: number;
};
