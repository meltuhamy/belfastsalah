import type CalculationParameters from './CalculationParameters.js';
import type Coordinates from './Coordinates.js';
export interface ValidPrayerTimesResult {
    isValid: true;
    fajr: Date;
    sunrise: Date;
    dhuhr: Date;
    asr: Date;
    sunset: Date;
    maghrib: Date;
    isha: Date;
}
export interface InvalidPrayerTimesResult {
    isValid: false;
}
export type PrayerTimesResult = ValidPrayerTimesResult | InvalidPrayerTimesResult;
/**
 * Computes prayer times for a single day of solar geometry, with no
 * awareness of polar circle resolution. `date` is used both for the solar
 * geometry and for labeling the returned times; if any of them can't be
 * computed or end up out of order, every field is set to an invalid `Date`
 * (see `isValid`).
 */
export declare function computePrayerTimesForDay(coordinates: Coordinates, date: Date, calculationParameters: CalculationParameters): PrayerTimesResult;
/**
 * Shifts every field of a result by a whole number of calendar days. Used to
 * relabel a polar-circle-resolved result (computed using a substitute day or
 * location) onto the originally requested date. `days` must be an integer;
 * this adds an exact `days * 86400` seconds, which only equals a calendar-day
 * shift because every field above is UTC-anchored (via `TimeComponents.utcDate`)
 * and UTC has no DST, so this stays exact regardless of the local timezone.
 */
export declare function shiftPrayerTimesByDays(result: PrayerTimesResult, days: number): PrayerTimesResult;
