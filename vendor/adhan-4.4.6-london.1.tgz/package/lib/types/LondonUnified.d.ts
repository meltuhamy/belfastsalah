export declare function londonUnifiedFajrInterval(date: Date): number;
export declare function londonUnifiedIshaInterval(date: Date): number;
export declare function londonUnifiedDailyAdjustments(date: Date): {
    [prayer: string]: number;
};
