import Prayer from './Prayer.js';
import CalculationParameters from './CalculationParameters.js';
import Coordinates from './Coordinates.js';
import { ValueOf } from './TypeUtils.js';
/**
 * Computes prayer times for a given location, date, and set of calculation
 * parameters.
 *
 * Near the polar circles the sun may not rise or set, or may not reach the
 * angle required for a given prayer, on certain days of the year. By default
 * `calculationParameters.polarCircleResolution` is `AqrabBalad`, which
 * automatically substitutes the closest usable latitude in these cases. If a
 * substitute can't be found (or `polarCircleResolution` is `Unresolved`),
 * every prayer time field below is set to an invalid `Date` (i.e.
 * `isNaN(date.getTime())`) rather than a subset of them, so check `isValid`
 * (or an individual field) before using the times.
 *
 * The same happens when the input is invalid: a latitude outside ±90°, a
 * latitude or longitude that isn't a finite number, or an invalid `date`.
 */
export default class PrayerTimes {
    coordinates: Coordinates;
    date: Date;
    calculationParameters: CalculationParameters;
    fajr: Date;
    sunrise: Date;
    dhuhr: Date;
    asr: Date;
    sunset: Date;
    maghrib: Date;
    isha: Date;
    constructor(coordinates: Coordinates, date: Date, calculationParameters: CalculationParameters);
    /**
     * Whether all prayer times could be computed. This is false when the
     * coordinates or date are invalid, or when the location and date fall
     * inside a polar circle where the sun's position doesn't reach the angle
     * required for one or more prayers (see the class doc comment above).
     */
    get isValid(): boolean;
    timeForPrayer(prayer: ValueOf<typeof Prayer>): Date | null;
    currentPrayer(date?: Date): "none" | "sunrise" | "fajr" | "dhuhr" | "asr" | "maghrib" | "isha";
    nextPrayer(date?: Date): "none" | "sunrise" | "fajr" | "dhuhr" | "asr" | "maghrib" | "isha";
}
