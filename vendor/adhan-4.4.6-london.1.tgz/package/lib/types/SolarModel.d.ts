export declare const SolarModel: {
    readonly Interpolated: "interpolated";
    readonly Noon: "noon";
};
