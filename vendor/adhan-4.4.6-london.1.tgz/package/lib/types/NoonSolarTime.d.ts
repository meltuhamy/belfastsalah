import type Coordinates from './Coordinates.js';
import SolarCoordinates from './SolarCoordinates.js';
/**
 * Solar times for SolarModel.Noon: the sun's position is taken once, at 12h
 * UT on the date, and every time of the day is derived from it without
 * interpolation. Transit comes from the equation of time, and each other
 * event is the hour angle at which the sun reaches its altitude.
 *
 * It has the same shape as SolarTime, so the prayer time calculation does
 * not need to know which model it is using. All times are hours after 0h UT.
 */
export default class NoonSolarTime {
    observer: Coordinates;
    solar: SolarCoordinates;
    transit: number;
    sunrise: number;
    sunset: number;
    constructor(date: Date, coordinates: Coordinates, sunriseElevation?: number, sunsetElevation?: number);
    hourAngle(angle: number, afterTransit: boolean): number;
    afternoon(shadowLength: number): number;
}
