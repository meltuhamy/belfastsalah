import Coordinates from './Coordinates.js';
import type CalculationParameters from './CalculationParameters.js';
import type { PrayerTimesResult } from './PrayerTimesCalculation.js';
import { ValueOf } from './TypeUtils.js';
export declare const PolarCircleResolution: {
    readonly AqrabBalad: "AqrabBalad";
    readonly AqrabYaum: "AqrabYaum";
    readonly Unresolved: "Unresolved";
};
export declare const resolvePolarCircle: (resolver: ValueOf<typeof PolarCircleResolution>, coordinates: Coordinates, date: Date, calculationParameters: CalculationParameters) => PrayerTimesResult | null;
